//
//  SecondViewController.swift
//  Ecobin_display
//
//  Created by Hayato Nakamura on 2019/04/02.
//  Copyright © 2019 Hayatopia. All rights reserved.
//

import UIKit

struct Ecobin_Data: Decodable {
    let accuracy: Double
    let accuracyavg: Double
    let id: Int
    let name: String
    let recyclable: Int
    let string: String
    let trash: Int
    let type: String
}


class SecondViewController: UIViewController {

    @IBOutlet weak var object_label: UILabel!
    @IBOutlet weak var accuracy_label: UILabel!
    @IBOutlet weak var type_label: UILabel!
    
    @IBOutlet weak var trash_image: UIImageView!
    @IBOutlet weak var recycle_image: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        trash_image.isHidden = true
        recycle_image.isHidden = true
        
        let apiurl: String = "http://128.31.22.22:8080/ecobinC/api/v1.0/classify/1"
        guard let url = URL(string: apiurl) else {return}
        let username = "ecobin-x"
        let password = "ecobinpass"
        let loginData = String(format: "%@:%@", username, password).data(using: String.Encoding.utf8)!
        let base64LoginData = loginData.base64EncodedString()
    
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Basic \(base64LoginData)", forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, err) in
            guard let data = data else {return}
            do {
                
                let new = try JSONDecoder().decode(Ecobin_Data.self, from: data)
                
                print("Accuracy")
                print(new.accuracy)
                let accuracy_data = String(new.accuracy)
                var new_acc = ""
                var counter = 0
                var dec = 0
                for character in accuracy_data {
                    if (String(character) != "." && dec == 0){
                    new_acc += String(character)
                    }
                    else{
                        dec = 1
                        counter += 1
                        if (counter < 4) {
                        new_acc += String(character)
                        }
                    }
                }
                
                var acc_avg = String(new.accuracyavg)
                dec = 0
                counter = 0
                var new_acc_av = ""
                for character in acc_avg{
                    if (String(character) != "." && dec == 0){
                        new_acc_av += String(character)
                    }
                    else{
                        dec = 1
                        counter += 1
                        if (counter < 4) {
                            new_acc_av += String(character)
                        }
                    }
                }
                
                print(new_acc)
                
                let object_data = String(new.name)
                let type_data = String(new.type)
                
                // Setting
                let defaults = UserDefaults.standard
                defaults.set(Double(new.trash), forKey: "keyTrash")
                defaults.set(Double(new.recyclable), forKey: "keyRec")
                defaults.set(Double(new_acc_av), forKey: "keyAcc")

                DispatchQueue.main.async {
                    
                    // Do all your UI stuff here
                    self.set_labels(accuracy: new_acc, object: object_data, type: type_data)
                    if (String(new.type) == "trash") {
                        self.trash_image.isHidden = false
                        self.recycle_image.isHidden = true
                    }
                    else if (String(new.type) == "recyclable") {
                        self.trash_image.isHidden = true
                        self.recycle_image.isHidden = false
                    }
                }
                
                
            }
            catch{
                print("error")
            }
            }
        task.resume()
        


        // Do any additional setup after loading the view.
    }
    
    func set_labels(accuracy: String, object: String, type: String) {
        self.accuracy_label.text = accuracy
        self.object_label.text = object
        self.type_label.text = type
    }
    
    @IBAction func refresh_pressed(_ sender: Any) {
        
        print("refreshed clicked")
        
        let apiurl: String = "http://128.31.22.22:8080/ecobinC/api/v1.0/classify/1"
        guard let url = URL(string: apiurl) else {return}
        let username = "ecobin-x"
        let password = "ecobinpass"
        let loginData = String(format: "%@:%@", username, password).data(using: String.Encoding.utf8)!
        let base64LoginData = loginData.base64EncodedString()
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Basic \(base64LoginData)", forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, err) in
            guard let data = data else {return}
            do {
                
                let new = try JSONDecoder().decode(Ecobin_Data.self, from: data)
                let accuracy_data = String(new.accuracy)
                var new_acc = ""
                var counter = 0
                var dec = 0
                for character in accuracy_data {
                    if (String(character) != "." && dec == 0){
                        new_acc += String(character)
                    }
                    else{
                        dec = 1
                        counter += 1
                        if (counter < 4) {
                            new_acc += String(character)
                        }
                    }
                }
                
                var acc_avg = String(new.accuracyavg)
                dec = 0
                counter = 0
                var new_acc_av = ""
                for character in acc_avg{
                    if (String(character) != "." && dec == 0){
                        new_acc_av += String(character)
                    }
                    else{
                        dec = 1
                        counter += 1
                        if (counter < 4) {
                            new_acc_av += String(character)
                        }
                    }
                }
                
                print(new_acc)
                
                let object_data = String(new.name)
                let type_data = String(new.type)
                
                // Setting
                let defaults = UserDefaults.standard
                defaults.set(Double(new.trash), forKey: "keyTrash")
                defaults.set(Double(new.recyclable), forKey: "keyRec")
                defaults.set(Double(new_acc_av), forKey: "keyAcc")
                
                DispatchQueue.main.async {
                    
                    // Do all your UI stuff here
                    self.set_labels(accuracy: new_acc, object: object_data, type: type_data)
                    if (String(new.type) == "trash") {
                        self.trash_image.isHidden = false
                        self.recycle_image.isHidden = true
                    }
                    else if (String(new.type) == "recycle") {
                        self.trash_image.isHidden = true
                        self.recycle_image.isHidden = false
                    }
                }
                
                
            }
            catch{
                print("error")
            }
        }
        task.resume()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
