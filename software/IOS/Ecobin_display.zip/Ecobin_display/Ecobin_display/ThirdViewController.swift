//
//  ThirdViewController.swift
//  Ecobin_display
//
//  Created by Hayato Nakamura on 2019/04/02.
//  Copyright © 2019 Hayatopia. All rights reserved.
//

import UIKit
import Charts


class ThirdViewController: UIViewController {

    @IBOutlet weak var PieChart: PieChartView!
    @IBOutlet weak var total_accuracy: UILabel!
    @IBOutlet weak var total_trash: UILabel!
    @IBOutlet weak var total_recyclable: UILabel!
    
    
    
    var trash_entry = PieChartDataEntry(value: 0)
    var recycle_entry = PieChartDataEntry(value: 0)
    var numdownloads = [PieChartDataEntry]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        PieChart.chartDescription?.text = ""
        trash_entry.label = "Trash"
        recycle_entry.label = "Recycle"
        trash_entry.value =  UserDefaults.standard.double(forKey: "keyTrash")
        recycle_entry.value = UserDefaults.standard.double(forKey: "keyRec")
        numdownloads = [trash_entry, recycle_entry]
        update_chart()
        
        
        self.total_accuracy.text = String(UserDefaults.standard.double(forKey: "keyAcc"))
        self.total_trash.text = String(UserDefaults.standard.double(forKey: "keyTrash"))
        self.total_recyclable.text = String(UserDefaults.standard.double(forKey: "keyRec"))
        
        
        // Do any additional setup after loading the view.
    }
    
    func update_chart() {
        let chartDataSet = PieChartDataSet(values: numdownloads, label: nil)
        let chartData = PieChartData(dataSet: chartDataSet)
        let t_color = #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
        let r_color = #colorLiteral(red: 0.1411764771, green: 0.3960784376, blue: 0.5647059083, alpha: 1)
        let colors = [t_color, r_color]
        chartDataSet.colors = colors as! [NSUIColor]
        PieChart.data = chartData
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
