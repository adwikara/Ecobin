//
//  ViewController.swift
//  Ecobin_display
//
//  Created by Hayato Nakamura on 2019/04/02.
//  Copyright © 2019 Hayatopia. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var start: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        start.layer.cornerRadius = 10
        start.clipsToBounds = true
    }


}

